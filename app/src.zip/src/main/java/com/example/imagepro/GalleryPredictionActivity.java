package com.example.imagepro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.opencv.android.Utils;
import org.opencv.core.CvType;
import org.opencv.core.Mat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GalleryPredictionActivity extends AppCompatActivity {
    private Button select_image;
    private ImageView image_v;
    private objectDetectionClass objectDetectionClass;
    int SELECT_PICTURE=200;
    private TextView recipesView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_prediction);

        select_image =findViewById(R.id.select_image);
        image_v =findViewById(R.id.image_v);
        recipesView = findViewById(R.id.recipes_view);  // Initialize the TextView

        try{
            // I used input size of 320 for this model
            objectDetectionClass =new objectDetectionClass(getAssets(),"custom_model.tflite","custom_label.txt",320);
            Log.d("MainActivity","Model is successfully loaded");
        }
        catch (IOException e){
            Log.d("MainActivity","Getting some error");
            e.printStackTrace();
        }

        select_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                image_chooser();
            }
        });
    }

    private void image_chooser() {
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(Intent.createChooser(i,"Select picture"),SELECT_PICTURE);

    }
    private List<String> findRecipes(List<String> ingredients) {
        // Below i have written the logic to find recipes based on detected ingredients
        List<String> recipes = new ArrayList<>();
        if (ingredients.contains("tomato") && ingredients.contains("garlic")) {
            recipes.add("Recipe You Can Make:  Tomato Garlic Pasta");
        }
        if (ingredients.contains("potato") && ingredients.contains("onion")) {
            recipes.add("Recipe You Can Make:  Potato Onion Soup");
        }
        if (ingredients.contains("tomato") && ingredients.contains("garlic")) {
            recipes.add("Recipe You Can Make:  Tomato Garlic Pasta");
        }
        if (ingredients.contains("potato")) {
            recipes.add("Recipe You Can Make:  Potato Soup");
        }
        return recipes;
    }

    private void displayRecipes(List<String> recipes) {
        // This line updates the TextView with recipes
        recipesView.setText(TextUtils.join("\n", recipes));
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Uri selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                Bitmap bitmap = null;
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Mat selected_image = new Mat(bitmap.getHeight(), bitmap.getWidth(), CvType.CV_8UC4);
                Utils.bitmapToMat(bitmap, selected_image);

                // This code here is used to handle the new return type
                Pair<Mat, List<String>> result = objectDetectionClass.recognizePhoto(selected_image);
                selected_image = result.first;
                List<String> detectedIngredients = result.second;

                Bitmap bitmap1 = Bitmap.createBitmap(selected_image.cols(), selected_image.rows(), Bitmap.Config.ARGB_8888);
                Utils.matToBitmap(selected_image, bitmap1);
                image_v.setImageBitmap(bitmap1);

                List<String> recipes = findRecipes(detectedIngredients);
                displayRecipes(recipes);
            }
        }
    }
}